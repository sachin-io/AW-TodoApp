(function() {
	/**
	 * When listener triggered , 'this' scope would return the app object scope.
	 * If it's required to post the message from app.js -> iframe (app URL) , 
	 * Use app scope like this.postMessage(String,Object);  
	 * String -> name of the event
	 * Object -> payload that needs to be delivered to iframe.
	 */
	return {

		onload: function() {
			console.log('on app load.');
		},
		pull : function(){
			console.log("Pull information from the server.");
		},
		save : function(){
			console.log("Listening customEvent from the iframe.");
		}
	}

}());
